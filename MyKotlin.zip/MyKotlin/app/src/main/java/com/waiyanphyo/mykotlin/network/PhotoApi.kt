package com.waiyanphyo.mykotlin.network

import com.waiyanphyo.mykotlin.data.vos.PhotoVO
import com.waiyanphyo.mykotlin.utils.API_KEY
import com.waiyanphyo.mykotlin.utils.GET_PHOTOS
import retrofit2.Call
import retrofit2.http.*

interface PhotoApi {

    @GET("/photos/")
    fun getAllPhotos() : Call<List<PhotoVO>>

//    @POST(LOGIN)
//    @FormUrlEncoded
//    fun login(@Field(PARAM_ACCESS_TOKEN)accessToken: String, @Field("email") email :String, @Field("password") password : String) : Call<LoginResponse>

}