package com.waiyanphyo.mykotlin.data.models

import com.waiyanphyo.mykotlin.network.dataagents.PhotoDataAgentImpl
import com.waiyanphyo.mykotlin.network.dataagents.PhotosDataAgent

abstract class BaseModel {
    protected val dataAgent = PhotoDataAgentImpl

}