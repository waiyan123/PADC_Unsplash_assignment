package com.waiyanphyo.mykotlin.network.dataagents

import android.annotation.SuppressLint
import android.content.Context
import com.waiyanphyo.mykotlin.MainApplication
import com.waiyanphyo.mykotlin.data.vos.PhotoVO
import com.waiyanphyo.mykotlin.network.PhotoApi
import com.waiyanphyo.mykotlin.utils.API_KEY
import com.waiyanphyo.mykotlin.utils.BASE_URL
import com.waiyanphyo.mykotlin.utils.HeaderInterceptor
import okhttp3.OkHttpClient
import retrofit2.*
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object PhotoDataAgentImpl : PhotosDataAgent {

    private val photoApi : PhotoApi
    init {
        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor(HeaderInterceptor(API_KEY))
            .connectTimeout(15,TimeUnit.SECONDS)
            .readTimeout(60,TimeUnit.SECONDS)
            .writeTimeout(60,TimeUnit.SECONDS)
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(okHttpClient)
            .build()

        photoApi = retrofit.create(PhotoApi::class.java)
    }

    override fun getAllPhotos(
        accessToken: String,
        onSuccess: (List<PhotoVO>) -> Unit,
        onFailure: (String) -> Unit
    ) {
        val call = photoApi.getAllPhotos()
        call.enqueue(object : Callback<List<PhotoVO>>{

            override fun onFailure(call: Call<List<PhotoVO>>, t: Throwable) {
                onFailure("Network issue")
            }

            override fun onResponse(call: Call<List<PhotoVO>>, response: Response<List<PhotoVO>>) {
                if(response.body()!=null){
                    val list = response.body()
                    onSuccess(response.body()!!)
                }
            }


        })
    }

}