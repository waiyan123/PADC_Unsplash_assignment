package com.waiyanphyo.mykotlin.data.models

import com.waiyanphyo.mykotlin.data.vos.PhotoVO

object PhotoModelImpl : BaseModel(),PhotoModel {


    override fun getAllPhotoFromNetwork(
        accessToken: String,
        onSuccess: (List<PhotoVO>) -> Unit,
        onFailure: (String) -> Unit
    ) {
        dataAgent.getAllPhotos(accessToken,{
            onSuccess(it)
        },{
            onFailure(it)
        })
    }

}