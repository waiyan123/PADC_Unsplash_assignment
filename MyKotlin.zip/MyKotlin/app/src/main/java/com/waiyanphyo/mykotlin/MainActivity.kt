package com.waiyanphyo.mykotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.waiyanphyo.mykotlin.data.models.PhotoModelImpl
import com.waiyanphyo.mykotlin.utils.API_KEY

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val model = PhotoModelImpl
        model.getAllPhotoFromNetwork("",
            {
                Toast.makeText(this,it.size,Toast.LENGTH_SHORT).show()
            },
            {
                Toast.makeText(this,it,Toast.LENGTH_SHORT).show()
            })

    }
}
