package com.waiyanphyo.mykotlin.utils

const val API_KEY = "1e214b48717943215f169f19160d9f05796a1fd3585ba0ff38f455c718530b46"

const val BASE_URL = "https://api.unsplash.com"

const val GET_PHOTOS = "/photos"