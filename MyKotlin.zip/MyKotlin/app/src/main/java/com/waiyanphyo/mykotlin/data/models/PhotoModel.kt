package com.waiyanphyo.mykotlin.data.models

import com.waiyanphyo.mykotlin.data.vos.PhotoVO

interface PhotoModel {

    fun getAllPhotoFromNetwork(
        accessToken : String,
        onSuccess : (List<PhotoVO>)-> Unit,
        onFailure : (String) -> Unit
    )

}