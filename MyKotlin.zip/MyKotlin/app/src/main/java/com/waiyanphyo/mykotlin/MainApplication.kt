package com.waiyanphyo.mykotlin

import android.app.Application
import android.content.Context

class MainApplication : Application(){

     companion object {
         fun getContext() : Context = this.getContext()
     }

}