package com.waiyanphyo.mykotlin.network.dataagents

import com.waiyanphyo.mykotlin.data.vos.PhotoVO

interface PhotosDataAgent {

    fun getAllPhotos(
        accessToken : String,
        onSuccess : (List<PhotoVO>)-> Unit,
        onFailure : (String) -> Unit
    )
}